package ch.makery.address.view
import scalafxml.core.macros.sfxml


@sfxml
class RootController() {
    def handleClose(){
        System.exit(0)
    }
}